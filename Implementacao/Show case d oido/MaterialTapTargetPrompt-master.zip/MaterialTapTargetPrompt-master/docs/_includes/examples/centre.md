## Centre

![Centre Example](assets/example_centre.png)

The prompt size will automatically be optimised to be positioned off centre from the target when the target is over 88dp from the screen edge.
